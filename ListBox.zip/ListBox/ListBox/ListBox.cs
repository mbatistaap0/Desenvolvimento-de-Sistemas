﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ListBox
{
    public partial class ListBox : Form
    {
        public ListBox()
        {
            InitializeComponent();
        }

        private void ListBox_Activated(object sender, EventArgs e)
        {
            lstBoxCidades.Items.Add("Caçapava");
            lblQtde.Text = Convert.ToString(lstBoxCidades.Items.Count);
        }

        private void btnAdicionar_Click(object sender, EventArgs e)
        {
            lstBoxCidades.Items.Add(txtCidade.Text);
            lblQtde.Text = Convert.ToString(lstBoxCidades.Items.Count);
        }


        private void btnRemover_Click(object sender, EventArgs e)
        {
            lstBoxCidades.Items.Remove(lstBoxCidades.SelectedItem);
            lblQtde.Text = Convert.ToString(lstBoxCidades.Items.Count);
        }

        private void ListBox_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (MessageBox.Show("Confirma sair da aplicação?", "Mensagem",
                MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                e.Cancel = false;
            else
                e.Cancel = true;
        }
    }
}
