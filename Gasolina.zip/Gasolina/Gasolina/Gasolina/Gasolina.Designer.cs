﻿namespace Gasolina
{
    partial class fGasolina
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(fGasolina));
            this.button1 = new System.Windows.Forms.Button();
            this.lblLitro = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.cbmCombustivel = new System.Windows.Forms.ComboBox();
            this.lblpsd = new System.Windows.Forms.Label();
            this.lblpcd = new System.Windows.Forms.Label();
            this.lblTotal = new System.Windows.Forms.Label();
            this.txtLitrosdesejado = new System.Windows.Forms.TextBox();
            this.lblPreçoSem = new System.Windows.Forms.Label();
            this.lblPreçoCom = new System.Windows.Forms.Label();
            this.lblLitroResp = new System.Windows.Forms.Label();
            this.btnSair = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft YaHei UI", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(347, 445);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(128, 56);
            this.button1.TabIndex = 0;
            this.button1.Text = "Calcular";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // lblLitro
            // 
            this.lblLitro.AutoSize = true;
            this.lblLitro.Font = new System.Drawing.Font("Microsoft YaHei UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLitro.Location = new System.Drawing.Point(44, 199);
            this.lblLitro.Name = "lblLitro";
            this.lblLitro.Size = new System.Drawing.Size(246, 30);
            this.lblLitro.TabIndex = 1;
            this.lblLitro.Text = "Quantos litros deseja?";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft YaHei UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(44, 48);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(230, 30);
            this.label2.TabIndex = 2;
            this.label2.Text = "Qual o combustível?";
            // 
            // cbmCombustivel
            // 
            this.cbmCombustivel.Font = new System.Drawing.Font("Microsoft YaHei UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbmCombustivel.FormattingEnabled = true;
            this.cbmCombustivel.Items.AddRange(new object[] {
            "Álcool",
            "Gasolina"});
            this.cbmCombustivel.Location = new System.Drawing.Point(49, 90);
            this.cbmCombustivel.Name = "cbmCombustivel";
            this.cbmCombustivel.Size = new System.Drawing.Size(184, 35);
            this.cbmCombustivel.TabIndex = 3;
            this.cbmCombustivel.DropDownStyleChanged += new System.EventHandler(this.cbmCombustivel_DropDownStyleChanged);
            this.cbmCombustivel.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cbmCombustivel_KeyDown);
            // 
            // lblpsd
            // 
            this.lblpsd.AutoSize = true;
            this.lblpsd.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpsd.Location = new System.Drawing.Point(12, 376);
            this.lblpsd.Name = "lblpsd";
            this.lblpsd.Size = new System.Drawing.Size(214, 24);
            this.lblpsd.TabIndex = 4;
            this.lblpsd.Text = "Preço sem desconto: R$";
            // 
            // lblpcd
            // 
            this.lblpcd.AutoSize = true;
            this.lblpcd.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpcd.Location = new System.Drawing.Point(12, 415);
            this.lblpcd.Name = "lblpcd";
            this.lblpcd.Size = new System.Drawing.Size(216, 24);
            this.lblpcd.TabIndex = 5;
            this.lblpcd.Text = "Preço com desconto: R$";
            // 
            // lblTotal
            // 
            this.lblTotal.AutoSize = true;
            this.lblTotal.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotal.Location = new System.Drawing.Point(12, 463);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(128, 24);
            this.lblTotal.TabIndex = 6;
            this.lblTotal.Text = "Total a pagar:";
            // 
            // txtLitrosdesejado
            // 
            this.txtLitrosdesejado.Font = new System.Drawing.Font("Microsoft YaHei UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLitrosdesejado.Location = new System.Drawing.Point(49, 245);
            this.txtLitrosdesejado.Name = "txtLitrosdesejado";
            this.txtLitrosdesejado.Size = new System.Drawing.Size(100, 35);
            this.txtLitrosdesejado.TabIndex = 7;
            // 
            // lblPreçoSem
            // 
            this.lblPreçoSem.AutoSize = true;
            this.lblPreçoSem.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPreçoSem.Location = new System.Drawing.Point(232, 376);
            this.lblPreçoSem.Name = "lblPreçoSem";
            this.lblPreçoSem.Size = new System.Drawing.Size(0, 24);
            this.lblPreçoSem.TabIndex = 8;
            // 
            // lblPreçoCom
            // 
            this.lblPreçoCom.AutoSize = true;
            this.lblPreçoCom.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPreçoCom.Location = new System.Drawing.Point(234, 415);
            this.lblPreçoCom.Name = "lblPreçoCom";
            this.lblPreçoCom.Size = new System.Drawing.Size(0, 24);
            this.lblPreçoCom.TabIndex = 9;
            // 
            // lblLitroResp
            // 
            this.lblLitroResp.AutoSize = true;
            this.lblLitroResp.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLitroResp.Location = new System.Drawing.Point(149, 463);
            this.lblLitroResp.Name = "lblLitroResp";
            this.lblLitroResp.Size = new System.Drawing.Size(0, 24);
            this.lblLitroResp.TabIndex = 10;
            // 
            // btnSair
            // 
            this.btnSair.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btnSair.Font = new System.Drawing.Font("Microsoft YaHei UI", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSair.Image = ((System.Drawing.Image)(resources.GetObject("btnSair.Image")));
            this.btnSair.Location = new System.Drawing.Point(414, 398);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(61, 41);
            this.btnSair.TabIndex = 11;
            this.btnSair.UseVisualStyleBackColor = false;
            this.btnSair.Click += new System.EventHandler(this.btnSair_Click);
            // 
            // fGasolina
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(487, 518);
            this.Controls.Add(this.btnSair);
            this.Controls.Add(this.lblLitroResp);
            this.Controls.Add(this.lblPreçoCom);
            this.Controls.Add(this.lblPreçoSem);
            this.Controls.Add(this.txtLitrosdesejado);
            this.Controls.Add(this.lblTotal);
            this.Controls.Add(this.lblpcd);
            this.Controls.Add(this.lblpsd);
            this.Controls.Add(this.cbmCombustivel);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblLitro);
            this.Controls.Add(this.button1);
            this.Name = "fGasolina";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Gasolina e Álcool";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.fGasolina_FormClosing);
            this.Load += new System.EventHandler(this.fGasolina_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label lblLitro;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cbmCombustivel;
        private System.Windows.Forms.Label lblpsd;
        private System.Windows.Forms.Label lblpcd;
        private System.Windows.Forms.Label lblTotal;
        private System.Windows.Forms.TextBox txtLitrosdesejado;
        private System.Windows.Forms.Label lblPreçoSem;
        private System.Windows.Forms.Label lblPreçoCom;
        private System.Windows.Forms.Label lblLitroResp;
        private System.Windows.Forms.Button btnSair;
    }
}

