﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gasolina
{
    public partial class fGasolina : Form
    {
        public fGasolina()
        {
            InitializeComponent();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void cbmCombustivel_DropDownStyleChanged(object sender, EventArgs e)
        {
            this.cbmCombustivel.DropDownStyle = ComboBoxStyle.DropDownList;
        }


        private void button1_Click(object sender, EventArgs e)
        {
            double vQtdLitros, vDescontoPorLitroA = 0, vValorTotalAlcom, vValorTotalAlsem, vValorTotalGas, vValorTotalGasem;

            vQtdLitros = Convert.ToDouble(txtLitrosdesejado.Text);

            if (cbmCombustivel.Text == "Álcool")
            {
                lblPreçoSem.Text = String.Format("{0:n2}" , 3.19);
                if (vQtdLitros <= 20)
                    vDescontoPorLitroA = 3.19 - (3.19 * 0.05);

                if (vQtdLitros > 20)
                    vDescontoPorLitroA = 3.19 - (3.19 * 0.03);
            }

            vValorTotalAlcom =  (vQtdLitros * vDescontoPorLitroA);
            lblPreçoCom.Text = String.Format("{0:n2}", vDescontoPorLitroA);
            vValorTotalAlsem = (vQtdLitros * 3.19);

            lblLitroResp.Text =  String.Format("{0:n2}", vValorTotalAlcom);


            if (cbmCombustivel.Text == "Gasolina")
            {
                lblPreçoSem.Text = String.Format("{0:n2}", 4.29);
                if (vQtdLitros <= 20)
                    vDescontoPorLitroA = 4.29 - (4.29 * 0.04);

                if (vQtdLitros > 20)
                    vDescontoPorLitroA = 2.29 - (4.29 * 0.06);
            }

            vValorTotalGas = (vQtdLitros * vDescontoPorLitroA);
            lblPreçoCom.Text = String.Format("{0:n2}", vDescontoPorLitroA);
            vValorTotalGasem = (vQtdLitros * 4.29);

            lblLitroResp.Text = String.Format("{0:n2}", vValorTotalGasem);
        }


        private void cbmCombustivel_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                txtLitrosdesejado.Focus();
            }
        }

        private void fGasolina_Load(object sender, EventArgs e)
        {

        }

        private void fGasolina_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (MessageBox.Show("Confirma sair da aplicação?", "Mensagem",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                e.Cancel = false;
            else
                e.Cancel = true;
        }
    }
}
