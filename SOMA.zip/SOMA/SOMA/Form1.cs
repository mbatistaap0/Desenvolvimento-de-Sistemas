﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SOMA
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnSomar_Click(object sender, EventArgs e)
        {
            int vNum1, vNum2, vResult;

            if (txtValor1.Text == "")
            {
                MessageBox.Show("Valor 1 é obrigatório", "Mensagem",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtValor1.Focus();
                return;
            }
            if (txtValor2.Text == "")
            {
                MessageBox.Show("Valor 2 é obrigatório", "Mensagem",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtValor2.Focus();
                return;
            }

            vNum1 = int.Parse(txtValor1.Text);
            vNum2 = int.Parse(txtValor2.Text);
            vResult = vNum1 + vNum2;
            txtResultado.Text = vResult.ToString();
        }

        private void lblValor2_Click(object sender, EventArgs e)
        {

        }

        private void lblResultado_Click(object sender, EventArgs e)
        {

        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtResultado.Text = "0";
            txtValor1.Clear();
            txtValor2.Clear();
            txtValor1.Focus();
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (MessageBox.Show("Confirma sair da aplicação?", "Mensagem",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                e.Cancel = false;
            else
                e.Cancel = true;

        }

        private void txtValor1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                txtValor2.Focus();
            }
        }
    }
}
