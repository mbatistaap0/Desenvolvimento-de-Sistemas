﻿namespace PrjForms
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbltela = new System.Windows.Forms.Label();
            this.btnTela2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbltela
            // 
            this.lbltela.AutoSize = true;
            this.lbltela.Font = new System.Drawing.Font("Microsoft YaHei UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltela.Location = new System.Drawing.Point(217, 206);
            this.lbltela.Name = "lbltela";
            this.lbltela.Size = new System.Drawing.Size(76, 30);
            this.lbltela.TabIndex = 0;
            this.lbltela.Text = "Tela 1";
            this.lbltela.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnTela2
            // 
            this.btnTela2.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTela2.Location = new System.Drawing.Point(418, 436);
            this.btnTela2.Name = "btnTela2";
            this.btnTela2.Size = new System.Drawing.Size(93, 37);
            this.btnTela2.TabIndex = 1;
            this.btnTela2.Text = "Tela 2";
            this.btnTela2.UseVisualStyleBackColor = true;
            this.btnTela2.Click += new System.EventHandler(this.btnTela2_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(523, 485);
            this.Controls.Add(this.btnTela2);
            this.Controls.Add(this.lbltela);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbltela;
        private System.Windows.Forms.Button btnTela2;
    }
}

