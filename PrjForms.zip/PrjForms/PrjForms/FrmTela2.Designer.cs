﻿namespace PrjForms
{
    partial class FrmTela2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnTela3 = new System.Windows.Forms.Button();
            this.lbltela2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnTela3
            // 
            this.btnTela3.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTela3.Location = new System.Drawing.Point(418, 436);
            this.btnTela3.Name = "btnTela3";
            this.btnTela3.Size = new System.Drawing.Size(93, 37);
            this.btnTela3.TabIndex = 3;
            this.btnTela3.Text = "Tela 3";
            this.btnTela3.UseVisualStyleBackColor = true;
            // 
            // lbltela2
            // 
            this.lbltela2.AutoSize = true;
            this.lbltela2.Font = new System.Drawing.Font("Microsoft YaHei UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltela2.Location = new System.Drawing.Point(217, 206);
            this.lbltela2.Name = "lbltela2";
            this.lbltela2.Size = new System.Drawing.Size(76, 30);
            this.lbltela2.TabIndex = 2;
            this.lbltela2.Text = "Tela 2";
            this.lbltela2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbltela2.Click += new System.EventHandler(this.lbltela_Click);
            // 
            // FrmTela2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(524, 484);
            this.Controls.Add(this.btnTela3);
            this.Controls.Add(this.lbltela2);
            this.Name = "FrmTela2";
            this.Text = "FrmTela2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnTela3;
        private System.Windows.Forms.Label lbltela2;
    }
}