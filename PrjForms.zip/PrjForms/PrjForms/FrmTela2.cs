﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PrjForms
{
    public partial class FrmTela2 : Form
    {
        public FrmTela2()
        {
            InitializeComponent();
        }

        private void lbltela_Click(object sender, EventArgs e)
        {

        }
    }
}
