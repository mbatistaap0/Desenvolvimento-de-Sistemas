﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IMC
{
    public partial class IMC : Form
    {
        public IMC()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double vPeso, vAlt, vResult;


            if (txtPeso.Text == "")
            {
                MessageBox.Show("O peso é obrigatória.", "Mensagem",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtPeso.Focus();
                return;
            }
            if (txtAlt.Text == "")
            {
                MessageBox.Show("A altura é obrigatória.", "Mensagem",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtAlt.Focus();
                return;
            }
            vPeso = double.Parse(txtPeso.Text);
            vAlt = double.Parse(txtAlt.Text);
            if (vPeso == 0)
            {
                MessageBox.Show("Não foi possível calcular. Tente novamente!", "Mensagem",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtPeso.Focus();
                return;
            }
            if (vAlt == 0)
            {
                MessageBox.Show("Não foi possível calcular. Tente novamente!", "Mensagem",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtAlt.Focus();
                return;
            }

            vPeso = double.Parse(txtPeso.Text);
            vAlt = double.Parse(txtAlt.Text);
            vResult = (vPeso / (vAlt * vAlt));
            lblIMC2.Text = vResult.ToString("n2");


            {
                if (vResult >= 18.5 && vResult <= 25)
                    lblSit2.Text = "Parabéns! Você está no peso ideal.";

                else 
                    lblSit2.Text = "Sinto muito! Você está fora do peso ideal.";
            }
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lblIMC2.Text = "0";
            lblSit2.Text = "---";
            txtAlt.Clear();
            txtPeso.Clear();
            txtPeso.Focus();
        }

        private void IMC_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (MessageBox.Show("Confirma sair da aplicação?", "Mensagem",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                e.Cancel = false;
            else
                e.Cancel = true;
        }

        private void txtPeso_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                txtAlt.Focus();
            }
        }

        private void txtPeso_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar) && e.KeyChar != (char)8 && e.KeyChar != (char)44
                && e.KeyChar != (char)45) // 8 = backspace, 44 = vírgula, 45 = negativos
            {
                e.Handled = true;
            }
        }

        private void txtAlt_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar) && e.KeyChar != (char)8 && e.KeyChar != (char)44
                && e.KeyChar != (char)45) // 8 = backspace, 44 = vírgula, 45 = negativos
            {
                e.Handled = true;
            }
        }
    }
}
